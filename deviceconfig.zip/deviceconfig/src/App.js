import React, { Component } from 'react'
import './App.css';

import  Navbars from './mainpage/navbar'

import   Mainlogic from './component/mainlogic'
class App extends Component {

  render(){
    return (
      <div >
        <Navbars></Navbars>
        <Mainlogic></Mainlogic>
      </div>
    )
  }
}

export default App;
