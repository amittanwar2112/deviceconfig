import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import {Form,Button} from 'react-bootstrap';


function Formlayout(props) {
 let customer_list=[];  
 let site_id_list=[];
 let gateway_id_list=[];
 //console.log(props.coustmerlist)
 //console.log(props.custmerid)
for(let i in props.coustmerlist){
customer_list.push(<option>{props.coustmerlist[i]}</option>)
}
for(let i in props.siteid){
    site_id_list.push(<option>{props.siteid[i]}</option>)
 }
for(let i in props.gatewayid){
    gateway_id_list.push(<option>{props.gatewayid[i]}</option>)
 }
  return (
    <div style={{textAlign:"center"}}>
        <Form.Label style={{margin:"5px"}}>Customer Name</Form.Label>
            <Form.Control as="select" onChange={props.chnagecoustmer} style={{textAlign:"center",width:"40%",border:"2px solid #b3ffb3",display:" inline"}}>
                <option></option>
                {customer_list}
        </Form.Control>

        <Form.Label style={{margin:"5px"}}>Select Site Id</Form.Label>
            <Form.Control as="select" onChange={props.changesite} style={{textAlign:"center",border:"2px solid #b3ffb3",display:" inline",width:"40%"}}>
                <option></option>
                {site_id_list}
        </Form.Control>

        <Form.Label style={{margin:"5px"}}>Select Device Type</Form.Label>
            <Form.Control as="select" onChange={props.changegateway} style={{textAlign:"center",border:"2px solid #b3ffb3",display:" inline",width:"40%",marginTop:"5px"}}>
                <option></option>
                {gateway_id_list}
        </Form.Control>



        <Button variant="primary" onClick={props.click} style={{display:"block",position:"absolute",left:"45%",marginTop:"5px"}}>Add Device</Button>
        
        { props.onadd === true ?
            <div style={{display:"block",position:"absolute",left:"45%",top:"30%"}}>
                <Form style={{textAlign:"center"}}>
                    <Form.Label>Select Device Type</Form.Label>
                    <Form.Control as="select" onChange={props.changedevicetype} style={{textAlign:"center"}}>
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                        <option>4</option>
                    </Form.Control>

                    <Form.Label>Select Connection Type</Form.Label>
                    <Form.Control as="select" onChange={props.changeconnectiontype} style={{textAlign:"center"}}>
                        <option>RTU</option>
                        <option>RTU</option>
                    </Form.Control>



                    <Form.Group style={{textAlign:"center",width:"100%",}}>
                        <Form.Label>Device Id</Form.Label>
                        <Form.Control type="deviceid" onChange={props.changedeviceid} placeholder="Enter Device Id" style={{textAlign:"center"}}/>
                    </Form.Group>

                    <Form.Label>Select Device Category</Form.Label>
                    <Form.Control as="select" onChange={props.changedevicecategory} style={{textAlign:"center"}}>
                        <option>Inverter</option>
                        <option>WST</option>
                    </Form.Control>


                    <Form.Group  style={{width:"100%",textAlign:"center"}}>
                    
                        <Form.Label>Salve Id</Form.Label>
                        <Form.Control type="slaveid" style={{textAlign:"center"}} onChange={props.changeslaveid} placeholder="Enter Slave Id" />
                    
                    </Form.Group>

                    <Form.Label>Select Baud Rate</Form.Label>
                    <Form.Control as="select" onChange={props.changebaudrate} style={{textAlign:"center"}}>
                        <option>9600</option>
                        <option>12000</option>
                    </Form.Control>


                    <Form.Label>Select Parity</Form.Label>
                    <Form.Control as="select" onChange={props.changeparity} style={{textAlign:"center"}}>
                        <option>None</option>
                        <option>Odd</option>
                        <option>Even</option>
                    </Form.Control>

                    <Form.Label>Select Stop bit</Form.Label>
                    <Form.Control as="select" onChange={props.changestopbit} style={{textAlign:"center"}}>
                        <option>1</option>
                        <option>1.5</option>
                        <option>2</option>
                    </Form.Control>

                    <Form.Label>Select Byte Size</Form.Label>
                    <Form.Control as="select" onChange={props.changebytesize} style={{textAlign:"center"}}>
                        <option>8</option>
                        <option>7</option>
                        <option>6</option>
                    </Form.Control>




                    <Button variant="primary" style={{textAlign:"center",marginTop:"5px"}} onClick={props.onsubmit}>
                        Submit
                    </Button>
                </Form>
            </div>  :null  
        }
            <Button variant="primary" style={{textAlign:"center",marginLeft:"5px",display:"block",position:"absolute",left:"55%",marginTop:"5px",}} onClick={props.onfinal}>
                Final Submit
            </Button>
    </div>
  )
}

export default Formlayout