import React, { Component } from 'react'
import  Formlayout from '../mainpage/formlayout'
import axios from 'axios'

 class Mainlogic extends Component {
    constructor(props) {
        super(props);
        this.customerdetails= {};
        this.configdataarray=[];
        this.state ={
        customeridlist:[],    
        coustmernamelist:[],
        gatewayidlist:[],  
        siteidlist:[],  
        coustmerid:0, 
        siteid:0,
        gatewayid:0,  
        device_type:"",
        connection_type:"RTU",
        device_id:"DLT001",
        device_category:"inverter",
        slave_id:1,
        baud_rate:9600,
        parity:"none",
        stop_bits:1,
        byte_size:8,
        addbutton: false,
        }
      }
    devicetype = (event) => {
      //console.log(event.target.value);
      //console.log(typeof (event.target.value));
      let dt=event.target.value;
      this.setState({device_type : event.target.value});
      console.log(this.state.device_type);

    }    
    connectiontype = (event) => {
        //console.log(event.target.value)
        this.setState({connection_type : event.target.value});
  
    } 
    deviceid = (event) => {
        //console.log(event.target.value)
        this.setState({device_id : event.target.value});
  
    } 
    devicecategory = (event) => {
        //console.log(event.target.value)
        this.setState({device_category : event.target.value});
  
    } 
    slaveid = (event) => {
        //console.log(event.target.value)
        let slaveidint=parseInt(event.target.value);
        this.setState({slave_id : slaveidint});

  
    }
    baudrate = (event) => {
        //console.log(event.target.value)
        let baudrateint=parseInt(event.target.value);
        this.setState({baud_rate : baudrateint});
  
    }
    selectparity = (event) => {
        //console.log(event.target.value)
        this.setState({parity : event.target.value});
  
    }
    selectstopbit = (event) => {
        //console.log(event.target.value)
        let stopbitint=parseInt(event.target.value);
        this.setState({stop_bits : stopbitint});
  
    }
    selectbytesize = (event) => {
        //console.log(event.target.value)
        let bytesizeint=parseInt(event.target.value);
        this.setState({byte_size : bytesizeint});
  
    }
    adddivice = (event) => {
        //console.log(event.target.value
        let x = this.state.addbutton
        this.setState({addbutton : !x});
      }

      selectcoustmerid = (event) => {
       
        this.setState({coustmerid: this.customerdetails[event.target.value]});
        //console.log(event.target.value);
        //console.log(this.customerdetails[event.target.value]);
       
        let url= 'http://127.0.0.1:5000/site?custome_id='+this.customerdetails[event.target.value]
        axios.get(url).then(response =>{
            //console.log(url)
            //console.log(response)
            this.setState({siteidlist: response.data.site_id});
            
        });
    
      }

      selectsiteid = (event) => {
        //console.log(event.target.value
        let stid=parseInt(event.target.value);
        this.setState({siteid: stid});
        
        axios.get('http://127.0.0.1:5000/gateway?site_id='+stid).then(response =>{
            //console.log(response)
            //console.log(response.data.customer_name)
            this.setState({gatewayidlist: response.data.gateway_id});
            
        });
      }

      selectgatewyid = (event) => {
        //console.log(event.target.value
       
        //this.setState({gatewayid: gtid});
        this.setState({gatewayid : event.target.value}); 
      }

      componentDidMount = () => {
        
        //this.customerdata();

        axios.get('http://127.0.0.1:5000/coustmer').then(response =>{
            //console.log(response)
            let cname=response.data.customer_name;
            let cid=response.data.coustomer_id
            
            for(let i in cname){
                //console.log(cname[i]);
                this.customerdetails[cname[i]]=cid[i]
            }
            //console.log(response.data.customer_name)
            //console.log(this.customerdetails);
            this.setState({coustmernamelist : response.data.customer_name,
                customeridlist:response.data.coustomer_id
            });
            
        });

    }

    
    creatingjsondataarray =()=>{
        let jasonobject={
            "device_type":this.state.device_type,
            "connection_type":this.state.connection_type,
          "device_id":this.state.device_id,
          "device_category":this.state.device_category,
            "connection_param": {
                  "slave_id":this.state.slave_id,
                  "baud_rate":this.state.baud_rate,
                  "parity":this.state.parity,
                  "stop_bits":this.state.stop_bits,
                  "byte_size":this.state.byte_size
            }
        }
        
        this.configdataarray.push(jasonobject);
        this.setState({addbutton : false});

    }

    onfinalsubmit =()=>{
        let gatewaydetails={
            "customer_id":this.state.coustmerid,
            "site_id":this.state.siteid,
          "gateway_id":this.state.gatewayid ,
          "config_array":this.configdataarray
        }
        console.log(this.configdataarray);
        
            axios.post('http://127.0.0.1:8000/updatedeviceconfig',gatewaydetails).then(response =>{
                console.log(response)
            });
           
            //console.log(dataarray);
   
    }

  render() {
    return (
      <div>
        <Formlayout
        gatewayid={this.state.gatewayidlist}
        siteid={this.state.siteidlist}
        custmerid={this.state.customeridlist}
        coustmerlist={this.state.coustmernamelist}
        chnagecoustmer={this.selectcoustmerid}
        changesite={this.selectsiteid}
        changegateway={this.selectgatewyid} 
        onadd={this.state.addbutton}
        click={this.adddivice}
        changedevicetype={this.devicetype}
        changeconnectiontype={this.connectiontype}
        changedeviceid={this.deviceid}
        changedevicecategory={this. devicecategory}
        changeslaveid={this.slaveid}
        changebaudrate={this.baudrate}
        changeparity={this.selectparity}
        changestopbit={this.selectstopbit}
        changebytesize={this.selectbytesize}
        onsubmit={this.creatingjsondataarray}
        onfinal={this.onfinalsubmit}>
        </Formlayout>
      </div>
    )
  }
}

export default Mainlogic
